import java.util.Scanner;

public class LibraryManagement {
    Scanner scanner = new Scanner(System.in);

    void printMenu(Borrowable book) {

        while(true) {
            System.out.println("1 - Borrow a book");
            System.out.println("2 - Return a book");
            System.out.println("0 - Exit");

            int input = scanner.nextInt();
            switch (input) {
                case 1 -> {
                    book.borrow();
                }
                case 2 -> {
                    book.returnBook();
                }
                case 0 -> {
                    System.out.println("Bye!");
                    System.exit(0);
                }
                default -> throw new IllegalStateException("Unexpected value: " + input);
            }
        }


    }
}
