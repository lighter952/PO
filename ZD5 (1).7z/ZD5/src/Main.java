// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
        LibraryManagement manager = new LibraryManagement();
        FictionBook book = new FictionBook("The Great Gatsby", "F. Scott Fitzgerald", 1925, "Classic");
        manager.printMenu(book);
    }
}