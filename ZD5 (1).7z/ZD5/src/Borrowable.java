public interface Borrowable {
    public void borrow();
    public void returnBook();
}
